SUGAR version 1.0.0

To run the Sugar, pre-installation of the Java Runtime Environment is required (see the URL http://java.com/).

Usage:
start GUI: java -jar Sugar.jar [options]
run Console: java -jar Sugar.jar [options] seqfile1 seqfile2 ... seqfileN

Command example:
If you analyze two Fastq files named test01_R2.fastq and test01_R2.fastq with definition of low quality threshold 30 (Phred) and 20x20 resolution per tile, type the command:
java -jar Sugar.jar --heatmap_quality_threshold 30 --matrix_size 20 test01_R2.fastq test01_R2.fastq

To get more help, type the command:
java -jar Sugar.jar -h
